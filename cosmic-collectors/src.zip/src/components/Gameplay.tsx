import { FaGamepad, FaCoins, FaUsersCog } from 'react-icons/fa'

const Gameplay = () => {
  return (
    <section className="py-20 bg-gradient-to-b from-gray-950 to-gray-900">
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          {/* Left Content */}
          <div className="lg:w-1/2">
            <h2 className="text-4xl font-bold mb-6 font-orbitron gradient-text">Experience the Adventure</h2>
            <p className="text-gray-400 mb-8">
              Dive into a rich universe filled with challenges, rewards, and endless possibilities.
              Your NFT collection directly impacts your gameplay experience.
            </p>

            <div className="space-y-6">
              {/* Feature 1 */}
              <div className="flex items-start">
                <div className="bg-purple-900 rounded-full p-3 mr-4">
                  <FaGamepad className="text-purple-300" />
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Interactive Gameplay</h3>
                  <p className="text-gray-400">
                    Control your ship, engage in battles, and explore new galaxies with intuitive controls.
                  </p>
                </div>
              </div>

              {/* Feature 2 */}
              <div className="flex items-start">
                <div className="bg-pink-900 rounded-full p-3 mr-4">
                  <FaCoins className="text-pink-300" />
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Earn While Playing</h3>
                  <p className="text-gray-400">
                    Every mission completed and enemy defeated earns you valuable rewards.
                  </p>
                </div>
              </div>

              {/* Feature 3 */}
              <div className="flex items-start">
                <div className="bg-blue-900 rounded-full p-3 mr-4">
                  <FaUsersCog className="text-blue-300" />
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Upgrade System</h3>
                  <p className="text-gray-400">
                    Combine and upgrade your NFTs to create even more powerful assets.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Image + Overlay */}
          <div className="lg:w-1/2 relative">
            <div className="relative rounded-xl overflow-hidden border-2 border-purple-500">
              <img
                src="https://images.unsplash.com/photo-1639762681057-408e52192e55?q=80&w=1632&auto=format&fit=crop"
                alt="Gameplay"
                className="w-full h-auto"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-70" />
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <h3 className="text-xl font-bold mb-2">Space Battle Arena</h3>
                <p className="text-gray-300 mb-4">
                  Engage in epic 3D space battles with your collected NFTs
                </p>
                <div className="progress-bar w-full" />
              </div>
            </div>

            {/* Decorative Circles */}
            <div className="absolute -bottom-6 -left-6 w-32 h-32 rounded-full bg-purple-900 opacity-20 -z-10" />
            <div className="absolute -top-6 -right-6 w-40 h-40 rounded-full bg-pink-900 opacity-20 -z-10" />
          </div>
        </div>
      </div>
    </section>
  )
}

export default Gameplay
