'use client'

import { FaRocket, FaWallet, FaBars } from 'react-icons/fa'
import { useState } from 'react'
import ThemeSwitcher from './ThemeSwitcher'

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false)

  return (
    <header className="bg-gray-900 bg-opacity-80 backdrop-blur-sm sticky top-0 z-50 border-b border-gray-800">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        {/* Logo + Title */}
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-600 to-pink-500 flex items-center justify-center">
            <FaRocket className="text-white" />
          </div>
          <h1 className="text-2xl font-bold gradient-text font-orbitron">
            Cosmic Collectors
          </h1>
        </div>

        {/* Navigation */}
        <nav className="hidden md:flex space-x-8">
          {['Home', 'Marketplace', 'Leaderboard', 'My Collection', 'About'].map((item) => (
            <a key={item} href="#" className="text-white hover:text-purple-400 transition">
              {item}
            </a>
          ))}
        </nav>

        {/* Wallet + Mobile + Theme */}
        <div className="flex items-center space-x-4">
          <ThemeSwitcher />
          <button className="bg-gradient-to-r from-purple-600 to-pink-500 text-white px-4 py-2 rounded-full hover:opacity-90 transition flex items-center">
            <FaWallet className="mr-2" />
            <span>Connect Wallet</span>
          </button>
          <button
            className="md:hidden text-white"
            aria-label="Toggle Menu"
            onClick={() => setMenuOpen(!menuOpen)}
          >
            <FaBars className="text-2xl" />
          </button>
        </div>
      </div>
    </header>
  )
}

export default Header
