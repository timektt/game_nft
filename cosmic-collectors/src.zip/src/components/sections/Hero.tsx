import { FaPlay, FaStore } from 'react-icons/fa'

const Hero = () => {
  return (
    <section className="relative overflow-hidden">
      {/* Background Overlay */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-b from-purple-900 to-black opacity-70" />
        <div
          className="absolute inset-0 bg-cover bg-center opacity-20"
          style={{
            backgroundImage:
              "url('https://images.unsplash.com/photo-1534796636912-3b95b3ab5986?q=80&w=1471&auto=format&fit=crop')",
          }}
        />
      </div>

      {/* Hero Content */}
      <div className="container mx-auto px-4 py-20 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 font-orbitron">
            <span className="gradient-text">Collect</span> Unique{' '}
            <span className="gradient-text">Cosmic</span> NFTs
          </h1>
          <p className="text-xl text-gray-300 mb-10">
            Embark on an intergalactic adventure, collect rare NFTs, battle space pirates, and build your cosmic empire.
          </p>

          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <button className="bg-gradient-to-r from-purple-600 to-pink-500 text-white px-8 py-4 rounded-full hover:opacity-90 transition font-bold text-lg pulse">
              <FaPlay className="mr-2 inline-block" /> Start Adventure
            </button>
            <button className="bg-gray-800 bg-opacity-60 border border-gray-700 text-white px-8 py-4 rounded-full hover:bg-gray-700 transition font-bold text-lg">
              <FaStore className="mr-2 inline-block" /> Marketplace
            </button>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Hero
