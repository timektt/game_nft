import { FaCheckCircle, FaSpinner } from 'react-icons/fa'
import { FaClock } from 'react-icons/fa6'

const Roadmap = () => {
  return (
    <section className="py-20 bg-gray-900">
      <div className="container mx-auto px-4">
        {/* Title */}
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4 font-orbitron gradient-text">Development Roadmap</h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Our journey to build the ultimate NFT gaming experience
          </p>
        </div>

        <div className="relative">
          {/* Vertical timeline line */}
          <div className="hidden md:block absolute left-1/2 h-full w-1 bg-gradient-to-b from-purple-500 to-pink-500 -ml-0.5" />

          {/* Phase 1 */}
          <div className="relative md:flex justify-between items-center mb-20">
            <div className="md:w-5/12 mb-8 md:mb-0 md:pr-12 text-right">
              <div className="bg-gray-800 rounded-xl p-6 card-glow">
                <div className="flex items-center justify-end mb-4">
                  <span className="bg-purple-600 text-white text-sm font-bold px-3 py-1 rounded-full">Completed</span>
                </div>
                <h3 className="text-2xl font-bold mb-3">Phase 1: Foundation</h3>
                <ul className="text-gray-400 space-y-2">
                  {['Core game mechanics', 'Initial NFT collection', 'Basic marketplace'].map((item) => (
                    <li key={item} className="flex items-center justify-end">
                      <FaCheckCircle className="text-green-500 ml-2" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="hidden md:flex items-center justify-center w-2/12">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-600 to-pink-500 flex items-center justify-center text-white font-bold text-xl border-4 border-gray-900">
                Q1
              </div>
            </div>

            <div className="md:w-5/12" />
          </div>

          {/* Phase 2 */}
          <div className="relative md:flex justify-between items-center mb-20">
            <div className="md:w-5/12" />

            <div className="hidden md:flex items-center justify-center w-2/12">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-600 to-pink-500 flex items-center justify-center text-white font-bold text-xl border-4 border-gray-900">
                Q2
              </div>
            </div>

            <div className="md:w-5/12 md:pl-12">
              <div className="bg-gray-800 rounded-xl p-6 card-glow">
                <div className="flex items-center mb-4">
                  <span className="bg-blue-600 text-white text-sm font-bold px-3 py-1 rounded-full">In Progress</span>
                </div>
                <h3 className="text-2xl font-bold mb-3">Phase 2: Expansion</h3>
                <ul className="text-gray-400 space-y-2">
                  {['Guild system', 'New galaxy maps', 'Enhanced marketplace'].map((item) => (
                    <li key={item} className="flex items-center">
                      <FaSpinner className="text-blue-400 mr-2 animate-spin" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* Phase 3 */}
          <div className="relative md:flex justify-between items-center">
            <div className="md:w-5/12 mb-8 md:mb-0 md:pr-12 text-right">
              <div className="bg-gray-800 rounded-xl p-6 card-glow">
                <div className="flex items-center justify-end mb-4">
                  <span className="bg-gray-700 text-white text-sm font-bold px-3 py-1 rounded-full">Upcoming</span>
                </div>
                <h3 className="text-2xl font-bold mb-3">Phase 3: Evolution</h3>
                <ul className="text-gray-400 space-y-2">
                  {['3D space battles', 'NFT breeding', 'Mobile version'].map((item) => (
                    <li key={item} className="flex items-center justify-end">
                      <FaClock className="text-gray-500 ml-2" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="hidden md:flex items-center justify-center w-2/12">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-600 to-pink-500 flex items-center justify-center text-white font-bold text-xl border-4 border-gray-900">
                Q3
              </div>
            </div>

            <div className="md:w-5/12" />
          </div>
        </div>
      </div>
    </section>
  )
}

export default Roadmap
