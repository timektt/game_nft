'use client'

import { useState } from 'react'
import { FaWallet, FaCheckCircle } from 'react-icons/fa'

const FloatingWalletBtn = ({ onClick, isConnected }: { onClick: () => void; isConnected: boolean }) => {
  return (
    <div className="fixed bottom-8 right-8 z-40">
      <button
        onClick={onClick}
        aria-label="Connect Wallet"
        className={`w-14 h-14 rounded-full bg-gradient-to-br ${
          isConnected ? 'from-green-500 to-green-600' : 'from-purple-600 to-pink-500'
        } text-white flex items-center justify-center shadow-lg hover:opacity-90 transition floating`}
      >
        {isConnected ? <FaCheckCircle className="text-xl" /> : <FaWallet className="text-xl" />}
      </button>
    </div>
  )
}

export default FloatingWalletBtn